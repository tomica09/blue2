import{a as t}from"../chunks/entry.RZYzDLN8.js";export{t as start};
