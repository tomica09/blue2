import{a as t}from"../chunks/entry.DU-uMvIj.js";export{t as start};
