import{a as t}from"../chunks/entry.CvPmKWfz.js";export{t as start};
